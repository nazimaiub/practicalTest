﻿using practicalTest.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace practicalTest.Interfaces
{
    public interface IUserRepository
    {
        List<RegisterModel> GetUsers();      
        int RegisterUser(RegisterDto aUser);
        bool isRegisterUser(LoginInfo li);
        RegisterModel getUserByEmail(string email);


    }
}
