﻿using practicalTest.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace practicalTest.Interfaces
{
   
    public interface ITaskRepository
    {
        List<Tasks> GetTaskByUserId(int userId);
        List<Tasks> GetAllTask();
        int CreateTask(TasksDto aTask);
        bool EditTask(TasksDto aTask);
        bool DeleteTask(int taskid);

    }
}
