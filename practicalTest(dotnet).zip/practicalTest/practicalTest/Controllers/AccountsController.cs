﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using practicalTest.Models;
using Microsoft.AspNetCore.Identity;
using practicalTest.Interfaces;

namespace practicalTest.Controllers
{
    //[Route("api/[controller]")]
    //[ApiController]
    public class AccountsController : ControllerBase
    {
        private readonly AppData _appData;
        private readonly IUserRepository _userRepository;

        public AccountsController(IOptions<AppData> appData,IUserRepository userRepository)
        {

            _appData = appData.Value;
            this._userRepository = userRepository;

        }
        //[Authorize]
        // GET: api/Accounts
        [HttpGet]
        [Route("api/GetUsers")]
        public List<RegisterModel> GetUsers()
        {
            return _userRepository.GetUsers();
        }


        

        // POST: api/Accounts
        [HttpPost()]
        [Route("api/Register")]
        public int Register([FromBody]RegisterDto model)
        {
            //return 1;
            return _userRepository.RegisterUser(model);
            
        }
        [HttpPost()]
        [Route("api/Login")]
        public async Task<IActionResult> Login([FromBody] LoginInfo formdata)
        {       
            double tokenExpiryTime = Convert.ToDouble(_appData.ExpireTime);

            if (_userRepository.isRegisterUser(formdata)==true)
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes(_appData.Secret);
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(new Claim[]
                    {
                    new Claim(ClaimTypes.Email,formdata.Email)
                    }),
                    Expires = DateTime.UtcNow.AddDays(7),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                };

              

                    var token = tokenHandler.CreateToken(tokenDescriptor);
                RegisterModel aUser = _userRepository.getUserByEmail(formdata.Email);

                return Ok(new { token = tokenHandler.WriteToken(token), expiration = token.ValidTo, userType=aUser.UserType,userName=aUser.FirstName,userId=aUser.Id });
                
            }
        

            // return error
            ModelState.AddModelError("", "Username/Password was not Found");
            return Ok(new { token = false});

        }

        
        
    }
}
