﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using practicalTest.Interfaces;
using practicalTest.Models;

namespace practicalTest.Controllers
{
    //[Route("api/[controller]")]
    //[ApiController]
    public class TasksController : ControllerBase
    {
        private readonly ITaskRepository _taskRepository;
        // GET: api/Tasks
        public TasksController(ITaskRepository taskRepository)
        {
            this._taskRepository = taskRepository;
        }
        [HttpGet]
        [Route("api/GetTaskByUserId")]
        public List<Tasks> GetTaskByUserId([FromQuery]int userId)
        {
            return this._taskRepository.GetTaskByUserId(userId);
        }

        [HttpGet]
        [Route("api/GetAllTask")]
        public List<Tasks> GetAllTask()
        {
            return this._taskRepository.GetAllTask();
        }
        [Authorize]
        [HttpGet]
        [Route("api/DeleteTask")]
        public bool DeleteTask(int taskid)
        {
            return this._taskRepository.DeleteTask(taskid);
        }


        [Authorize]
        // POST: api/Tasks
        [HttpPost]
        [Route("api/CreateTask")]
        public int CreateTask(TasksDto model)
        {
            return _taskRepository.CreateTask(model);

        }

        [HttpPost]
        [Route("api/EditTask")]
        public bool EditTask([FromBody]TasksDto model)
        {
            return _taskRepository.EditTask(model);

        }

    }
}
