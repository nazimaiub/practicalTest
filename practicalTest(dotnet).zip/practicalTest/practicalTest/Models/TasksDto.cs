﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace practicalTest.Models
{
    public class TasksDto
    {
        
        public int Id { get; }
      
        public string taskName { get; set; }

     
        public string description { get; set; }

        
        public DateTime startDate { get; set; }

      
        public DateTime endDate { get; set; }

        public int userId { get; set; }
    }
}
