﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace practicalTest.Models
{
    public class Tasks
    {
        //Task Name, Description, Start Date, End Date

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required]
        [Display(Name = "Task Name")]
        [MaxLength(50, ErrorMessage = "Task name cant exceed 50 characters")]
        public string TaskName { get; set; }

        [Required]
        [Display(Name = "Description")]
        [MaxLength(250, ErrorMessage = "Description cant exceed 50 characters")]
        public string Description { get; set; }

        [Required]
        [Display(Name = "Start Date")]
        public DateTime StartDate { get; set; }

        [Required]
        [Display(Name = "End Date")]
        public DateTime EndDate { get; set; }

        [Required]
        public int UserId { get; set; }
    }
}
