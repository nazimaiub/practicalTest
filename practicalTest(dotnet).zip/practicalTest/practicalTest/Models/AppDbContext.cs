﻿
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace practicalTest.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {


        }
        public DbSet<RegisterModel> registrations { get; set; }
        public DbSet<Tasks> tasks { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<RegisterModel>()
            .Property(f => f.Id)
            .ValueGeneratedOnAdd();

            modelBuilder.Entity<Tasks>()
            .Property(f => f.Id)
            .ValueGeneratedOnAdd();
            //modelBuilder.Entity<RegisterModel>().HasData(
            //   new RegisterModel
            //   {
            //       Id=1,
            //       FirstName="nazim",
            //       LastName="ahmed",
            //       Email="a@b.com",
            //       Password="1234",
            //       mobile="023i193824",
            //       Address="dhaka"
                   
            //   }
               
            //   );
           


        }

    }
}
