﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace practicalTest.Models
{
    public class RegisterModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required]
        [Display(Name = "First Name")]
        [MaxLength(50, ErrorMessage = "First name cant exceed 50 characters")]
        public string FirstName { get; set; }
        [Required]
        [Display(Name = "last Name")]
        [MaxLength(50, ErrorMessage = "last name cant exceed 50 characters")]
        public string LastName { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [Required]
        [MaxLength(50, ErrorMessage = "mobile cant exceed 50 characters")]
        public string mobile { get; set; }
        [Required]
        [MaxLength(250, ErrorMessage = "Address cant exceed 50 characters")]
        public string Address { get; set; }
        
        public string UserType { get; set; }
    }
}
