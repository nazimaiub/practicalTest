﻿using practicalTest.Interfaces;
using practicalTest.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace practicalTest.Repository
{
    public class TaskRepository : ITaskRepository
    {
        public readonly AppDbContext context;
        // private readonly IHostingEnvironment hostingEnvironment;
        public TaskRepository(AppDbContext context)
        {
            //this.hostingEnvironment = hostingEnvironment;
            this.context = context;

        }
        public int CreateTask(TasksDto aTask)
        {
            Tasks tasks = new Tasks();
            tasks.TaskName = aTask.taskName;
            tasks.Description = aTask.description;
            tasks.StartDate = aTask.startDate;
            tasks.EndDate = aTask.endDate;
            tasks.UserId = aTask.userId;

            context.tasks.Add(tasks);
            context.SaveChanges();
            var current = context.tasks.Where(x => x.TaskName == aTask.taskName);
            if (current == null)
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }

        public bool DeleteTask(int taskid)
        {
            Tasks aTask=context.tasks.Where(x=>x.Id == taskid).SingleOrDefault();
            if(aTask!=null)
            {
                context.tasks.Remove(aTask);
                context.SaveChanges();
            }
            return true;

            
        }

        public bool EditTask(TasksDto aTask)
        {
            Tasks tasks = new Tasks();
            tasks.TaskName = aTask.taskName;
            tasks.Description = aTask.description;
            tasks.StartDate = aTask.startDate;
            tasks.EndDate = aTask.endDate;
            tasks.UserId = aTask.userId;
            //Tasks oneTask = context.tasks.Where(x => x.Id == aTask.Id).SingleOrDefault();
            //context.Entry(oneTask).State = System.Data.Entity.EntityState.Modified;
            context.Entry(tasks).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            context.SaveChanges();
            return true;
            
        }

        public List<Tasks> GetTaskByUserId(int userId)
        {
            var result= context.tasks.Where(x => x.UserId == userId).ToList();
            return result;

        }

        public List<Tasks> GetAllTask()
        {
            var result = context.tasks.ToList();
            return result;

        }

    }
}
