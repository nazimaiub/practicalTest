﻿using practicalTest.Interfaces;
using practicalTest.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace practicalTest.Repository
{
    public class UserRepository : IUserRepository
    {
        public readonly AppDbContext context;
       // private readonly IHostingEnvironment hostingEnvironment;
        public UserRepository(AppDbContext context)
        {
            //this.hostingEnvironment = hostingEnvironment;
            this.context = context;

        }
        public List<RegisterModel> GetUsers()
        {
            var result = context.registrations.ToList();
            return result;
        }
        public bool isEmailALredyRegisted(string email)
        {
            var result = context.registrations.Where(x => x.Email == email).SingleOrDefault();
            if (result != null)
            {
                return true;
            }

            return false;
        }

            public bool isRegisterUser(LoginInfo li)
        {
            var result = context.registrations.Where(x => x.Email == li.Email && x.Password == li.Password).SingleOrDefault();
            if(result!=null)
            {
                return true;
            }

            return false;

        }
        public RegisterModel getUserByEmail(string email)
        {
            return context.registrations.Where(x => x.Email == email).SingleOrDefault();

        }

        public int RegisterUser(RegisterDto aUser)
        {
            if (isEmailALredyRegisted(aUser.Email) == false)
            {
                RegisterModel rm = new RegisterModel();
                rm.FirstName = aUser.FirstName;
                rm.LastName = aUser.LastName;
                rm.mobile = aUser.mobile;
                rm.UserType = aUser.UserType;
                rm.Password = aUser.Password;
                rm.Address = aUser.Address;
                rm.Email = aUser.Email;
                context.registrations.Add(rm);
                context.SaveChanges();
                var current = context.registrations.Where(x => x.Email == aUser.Email);
                if (current == null)
                {
                    return 0;
                }
                else
                {
                    return 1;
                }
            }
            else
            {
                return -1;
            }
        }
    }
}
