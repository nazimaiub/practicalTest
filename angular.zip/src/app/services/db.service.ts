import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { register } from '../models/register';
import { responseData } from '../models/responseData';
import { LoginData } from '../models/LoginData';
import { tasks } from '../models/tasks';

@Injectable({
  providedIn: 'root'
})
export class DbService {
  private loginStatus = new BehaviorSubject<boolean>(false);
  constructor(private http: HttpClient ) { }
  changeLoginStatus(message: boolean) {
    this.loginStatus.next(message)
  }
  get isLoggesIn() 
      {
          return this.loginStatus.asObservable();
      }
  GetTaskByUserId(userId:Number):Observable<tasks[]>
  {
    //console.log("okuserId"+userId);
    return this.http.get<tasks[]>("https://localhost:44399/api/GetTaskByUserId?userId="+userId);

  }

  GetAllTask():Observable<tasks[]>
  {
    //console.log("okuserId"+userId);
    return this.http.get<tasks[]>("https://localhost:44399/api/GetAllTask");

  }

  getAllUsers():Observable<register>
  {
    //console.log("ok");
    return this.http.get<register>("https://localhost:44399/api/GetUsers");

  }
  saveRegistration(aRegistration:register)
  {
    // console.log(JSON.stringify(aRegistration));
    
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    let options = { headers: headers };
    //let options = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
    return this.http.post<string>("https://localhost:44399/api/Register", aRegistration,options);

  }

  checkUser (ldata:LoginData):Observable<responseData>
  {
    //console.log("hit check user");
    

   const body={
        Email:ldata.UserName,
        Password:ldata.Password

      }
      console.log(body);
      
      let headers = new HttpHeaders({
        'Content-Type': 'application/json'});
    let options = { headers: headers };
     return this.http.post<responseData>('https://localhost:44399/api/Login',body,options);
  }
  getAllvalue():Observable<string>
  {
    //console.log("ok");
    return this.http.get<string>("https://localhost:44399/api/values/GetbyId");

  }
  deletetask(taskName:number):Observable<string>
  {
    //console.log("oktaskid"+taskName);
    return this.http.get<string>("https://localhost:44399/api/DeleteTask?taskid="+taskName);

  }

  CreateTask(aTask:tasks)
  {
    const formData: FormData = new FormData();
    // console.log(JSON.stringify(aRegistration));
    //console.log("tname"+aTask.taskName);
    formData.append('taskName',aTask.taskName);
    formData.append('description',aTask.description);
    var datestr = (new Date(aTask.startDate)).toUTCString();
    formData.append('startDate',datestr);
    var dateend = (new Date(aTask.endDate)).toUTCString();
    formData.append('endDate',dateend);
    formData.append('UserId',aTask.userId.toString());
   
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    let options = { headers: headers };
    
    //let options = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
    return this.http.post<number>("https://localhost:44399/api/CreateTask", formData);

  }
}
