export class register
{
    Id:number;
    FirstName:string;
    LastName:string;
    Email:string;
    Password:string;
    Address:string;
    mobile:string;
    UserType:string;
}