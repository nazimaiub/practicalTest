export class responseData
{
    userId:Number;
    token:string;
    expiration:Date;
    userType:string;
    userName:string;
}