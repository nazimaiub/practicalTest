export class LoginData
{
    UserName:string;
    Password:string;
}