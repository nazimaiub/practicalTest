export class tasks
{
    id:Number;
    taskName:string;
    description:string;
    startDate:Date;
    endDate:Date;
    userId:number;
}