import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DbService } from '../services/db.service';

@Injectable({
  providedIn: 'root'
})


export class JwtInterceptor implements HttpInterceptor {

    constructor (private dbService:DbService) {}

    intercept(request : HttpRequest<any>, next : HttpHandler): Observable<HttpEvent<any>> 
    {
        // add authorization header with jwt token if available
        let currentuser = this.dbService.isLoggesIn;
        let token = localStorage.getItem('token');
        console.log("ok1");

        if (currentuser && token !== undefined) 
        {
            console.log("ok");
            request = request.clone({
                setHeaders: 
                {
                     Authorization: `Bearer ${token}` 
                    
                }
            });
        }
        console.log("ok2");
        return next.handle(request);
    }
}