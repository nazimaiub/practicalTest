import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserRegistrationComponent } from './components/user-registration/user-registration.component';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { CreateTaskComponent } from './components/create-task/create-task.component';
import { RegisterOtherUserComponent } from './components/register-other-user/register-other-user.component';
import { DeleteTaskComponent } from './components/delete-task/delete-task.component';


const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot([{
    path:'',
    component: UserRegistrationComponent
  },
  {
    path:'register',
    component: UserRegistrationComponent
  },
  {
    path:'login',
    component: LoginComponent
  },
  // {
  //   path:'home',
  //   component: HomeComponent
  // },
  {
    path: 'home',component: HomeComponent,
    children: [
      { path: 'userRegister', component: RegisterOtherUserComponent },
       { path: 'createTask', component: CreateTaskComponent },
       { path: 'deleteTask', component: DeleteTaskComponent },
      // { path: 'edit/:id', component: CreateEmployeeComponent },
    ]
  }
])],

  exports: [RouterModule]
})
export class AppRoutingModule { }
