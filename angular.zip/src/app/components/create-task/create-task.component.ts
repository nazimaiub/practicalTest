import { Component, OnInit } from '@angular/core';
import { FormGroup, NgForm } from '@angular/forms';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker/ngx-bootstrap-datepicker';
import { register } from 'src/app/models/register';
import { DbService } from 'src/app/services/db.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-task',
  templateUrl: './create-task.component.html',
  styleUrls: ['./create-task.component.scss']
})
export class CreateTaskComponent implements OnInit {
 //activedate=new Date();
  datePickerConfig:Partial<BsDatepickerConfig>;
  userList:register[];
  userId:Number;
  startDate=new Date();
  endDate=new Date();
  users=null;
  taskName:string;
  description:string;
  //trade=null;
  constructor(private dbService:DbService,private router: Router) { }

  ngOnInit(): void {
    this.GetAllUsers();
    this.datePickerConfig = Object.assign({},
      {
        containerClass: 'theme-blue',
        showWeekNumbers: false,
        dateInputFormat: 'DD/MM/YYYY'
      });
     
  }
  OnSubmit(form:NgForm)
  {
    console.log(JSON.stringify(form.value));
    this.dbService.CreateTask(form.value).subscribe((result:any)=>{
    
      this.setresponseValue(result);

  });

  }
  setresponseValue(result)
  {
    if(result>0)
      {
        
        alert('Task Added Successfully!! :-)\n\n');
        this.refreshData();
        //this.router.navigate(['/login']);
          //console.log(result);

      }
  }

  refreshData()
  {
    this.taskName="";
    this.description="";
    this.users=null;
    this.startDate=new Date();
    this.endDate=new Date();

  }
  GetAllUsers()
  {
    this.dbService.getAllUsers().subscribe((result:any)=>{
    
      this.setUserList(result);

  })

  //console.log(JSON.stringify(aRegistraion));
  
}
setUserList(result)
{
  this.userList=result;
  console.log(JSON.stringify(this.userList));
  

}


  

}
