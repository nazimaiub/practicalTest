import { Component, OnInit } from '@angular/core';
import { DbService } from 'src/app/services/db.service';
import { Router } from '@angular/router';
import { tasks } from 'src/app/models/tasks';

@Component({
  selector: 'app-delete-task',
  templateUrl: './delete-task.component.html',
  styleUrls: ['./delete-task.component.scss']
})
export class DeleteTaskComponent implements OnInit {
  taskList:tasks[];
  userType:string;
  constructor(private dbService:DbService,private router: Router) { }

  ngOnInit(): void {
    this.GetAllTask();
  }

  GetAllTask()
  {
    let userId=parseInt(localStorage.getItem('userId'));
    
    //console.log("uid"+userId);
    this.dbService.GetAllTask().subscribe((result:any)=>{
    
      this.setTaskList(result);

  });

  }
  setTaskList(result)
  {
    if(result!=null)
      {
        //console.log("uidres"+JSON.stringify(result));
        this.taskList=result;
      }
  }
  deleteTask(taskname:number)
  {
    this.dbService.deletetask(taskname).subscribe((result:any)=>{
    
      this.setStatus(result);

  });

  }
  setStatus(result)
  {
    if(result==true)
      {
        this.GetAllTask();
        alert('Task Deleted Successfully!! :-)\n\n');
        //console.log("uidres"+JSON.stringify(result));
       // this.taskList=result;
      }
  }

  }


