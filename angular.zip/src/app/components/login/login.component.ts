import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { DbService } from 'src/app/services/db.service';
import { responseData } from 'src/app/models/responseData';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  
  //public actorID:Number;
  //public tokenID:string;
  resp=new responseData();
  data:any;
  resStatus: boolean = false;

  constructor(private dbService:DbService,private router: Router) { }

  ngOnInit(): void {
    this.resStatus=false;
  }
  OnSubmit(form:NgForm)
  {
   // this.router.navigateByUrl("/home");
     localStorage.clear();
     this.dbService.checkUser(form.value).subscribe((result: any)=> {
       this.resp=result;
    
     if(result && result.token)
        {
        
          console.log("resp-true"+JSON.stringify(result));
          this.storeUserInfo(this.resp);
          
          
        }
    else
        {
          this.resStatus=true;
         
         //this.setErrMsg();
        }
        
        });
        
      }
    
    
    storeUserInfo(result:responseData)
    {
      
      if(result.token!=null)
      {
        this.dbService.changeLoginStatus(true);
        localStorage.setItem("token",result.token);
        localStorage.setItem("userName",result.userName);
        localStorage.setItem("userType",result.userType);
        localStorage.setItem("userId",result.userId.toString());
       
        this.router.navigate(['/home']);
      }
      else
      {
        this.resStatus=true;
        console.log('token is not set');
       
      }
     // this.getValue();


    }

    getValue()
    {
      this.dbService.getAllvalue().subscribe((result: any)=> {
        this.setr(result);

      })
    }
    setr(result)
    {

      console.log(result);
    }

}
