import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MustMatch } from 'src/app/helpers/must-match.validator';
import { register } from 'src/app/models/register';
import { DbService } from 'src/app/services/db.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.scss']
})
export class UserRegistrationComponent implements OnInit {

  registerForm: FormGroup;
  submitted = false;
  registerList:register[];
  emailexist:boolean=false;


  constructor(private formBuilder: FormBuilder,private dbService:DbService,private router: Router) { }

  ngOnInit() {
      this.registerForm = this.formBuilder.group({
          firstName: ['', Validators.required],
          lastName: ['', Validators.required],
          email: ['', [Validators.required, Validators.email]],
          mobile: ['', [Validators.required]],
          address: ['', Validators.required],
          password: ['', [Validators.required, Validators.minLength(6)]],
          confirmPassword: ['', Validators.required]
      }, {
          validator: MustMatch('password', 'confirmPassword')
      });
  }

  // convenience getter for easy access to form fields
  get f() { return this.registerForm.controls; }

  onSubmit() {
      this.submitted = true;
     

      // stop here if form is invalid
      if (this.registerForm.invalid) {
          return;
      }
      let aRegistraion=new register();
      //aRegistraion.Id=1;
      aRegistraion.FirstName=this.registerForm.controls.firstName.value;
      aRegistraion.LastName=this.registerForm.controls.lastName.value;
      aRegistraion.Email=this.registerForm.controls.email.value;
      aRegistraion.Password=this.registerForm.controls.password.value;
      aRegistraion.mobile=this.registerForm.controls.mobile.value;
      aRegistraion.Address=this.registerForm.controls.address.value;
      aRegistraion.UserType="admin";
      
      this.dbService.saveRegistration(aRegistraion).subscribe((result:any)=>{
          //this.registerList=result;
          this.setRegResponse(result);

      })

      console.log(JSON.stringify(aRegistraion));
      //alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.controls.firstName.value))
  }
  setRegResponse(result)
  {
      console.log("email"+result);
      if(result>0)
      {
        alert('Successfully Registered!! :-)\n\n')
        this.router.navigate(['/login']);
          //console.log(result);

      }
      else if(result<0)
      {
        console.log("email2"+result);
          this.emailexist=true;
          alert('Email ALready Exist!! :-)\n\n')

      }
  }


}
