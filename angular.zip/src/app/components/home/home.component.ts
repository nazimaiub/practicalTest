import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DbService } from 'src/app/services/db.service';
import { tasks } from 'src/app/models/tasks';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  taskList:tasks[];
  userType:string;

  constructor(private dbService:DbService,private router: Router) { }

  ngOnInit(): void {
    this.userType=localStorage.getItem('userType');
    this.GetTaskByUserId();
  }

  GetTaskByUserId()
  {
    let userId=parseInt(localStorage.getItem('userId'));
    
    console.log("uid"+userId);
    this.dbService.GetTaskByUserId(userId).subscribe((result:any)=>{
    
      this.setTaskList(result);

  });

  }
  setTaskList(result)
  {
    if(result!=null)
      {
        console.log("uidres"+JSON.stringify(result));
        this.taskList=result;
      }
  }


  logout():void
    {
      localStorage.clear();
      this.router.navigate(['login']);
  
    }

}
